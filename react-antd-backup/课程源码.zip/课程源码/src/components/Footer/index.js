import React from 'react'
import './index.less'
export default class Footer extends React.Component {
    render() {
        return (
            <div className="footer">
               版权所有：慕课网&河畔一角（推荐使用谷歌浏览器，可以获得更佳操作页面体验） 技术支持：河畔一角
            </div>
        );
    }
}