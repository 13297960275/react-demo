import React from 'react'
export default class About extends React.Component {

    render() {
        return (
            <div>
                this is about page.
            </div>
        );
    }
}